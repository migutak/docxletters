# docxletters
kubectl create -f deployment.yaml
kubectl create -f service.yaml