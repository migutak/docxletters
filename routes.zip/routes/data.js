module.exports = {
    filePath: '/Users/kevinabongo/demands/',
    imagePath: '/Users/kevinabongo/projects/docxletters/routes/',
    //filePath: '/home/ecollectadmin/demandletters/',
    //imagePath: '/home/ecollectadmin/docxletters/routes/',
}
